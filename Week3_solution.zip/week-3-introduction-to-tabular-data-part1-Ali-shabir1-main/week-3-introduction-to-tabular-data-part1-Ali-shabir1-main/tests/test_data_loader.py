import pandas as pd
from titanic_analysis.data_loader import load_titanic_data

def test_load_titanic_data():
    df = load_titanic_data(r"D:\Downloads\UK_Assignments\week-3-introduction-to-tabular-data-part1-Ali-shabir1-main\week-3-introduction-to-tabular-data-part1-Ali-shabir1-main\data\titanic.csv")
    assert isinstance(df, pd.DataFrame), "The returned object should be a DataFrame"
    assert not df.empty, "The DataFrame should not be empty"
