import pandas as pd

def display_unique_values(df: pd.DataFrame, categorical_features: list) -> dict:
    unique_values = {feature: df[feature].unique().tolist() for feature in categorical_features}
    return unique_values
