import pandas as pd

def load_titanic_data(filepath: str) -> pd.DataFrame:
    return pd.read_csv(filepath)
