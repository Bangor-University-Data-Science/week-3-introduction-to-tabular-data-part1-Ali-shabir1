import pandas as pd

def create_feature_type_dict(df: pd.DataFrame) -> dict:
    feature_types = {
        'numerical': {'continuous': [], 'discrete': []},
        'categorical': {'nominal': [], 'ordinal': []}
    }
    
    for column in df.columns:
        if pd.api.types.is_numeric_dtype(df[column]):
            if df[column].nunique() < 10:
                feature_types['numerical']['discrete'].append(column)
            else:
                feature_types['numerical']['continuous'].append(column)
        else:
            # Assume categorical data is nominal for simplicity
            feature_types['categorical']['nominal'].append(column)
            
    return feature_types
